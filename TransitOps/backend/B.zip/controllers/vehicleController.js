const Vehicle = require('../models/Vehicle');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const { successResponse } = require('../utils/response');
const { validationResult } = require('express-validator');

exports.list = catchAsync(async (req, res) => {
  const { page, limit, search, status, type, region, sortBy, order } = req.query;
  const result = await Vehicle.findAll({ page: parseInt(page) || 1, limit: parseInt(limit) || 10, search, status, type, region, sortBy, order });
  successResponse(res, result);
});

exports.getById = catchAsync(async (req, res) => {
  const vehicle = await Vehicle.findById(req.params.id);
  if (!vehicle) throw new AppError('Vehicle not found', 404);
  successResponse(res, vehicle);
});

exports.create = catchAsync(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) throw new AppError(errors.array().map(e => e.msg).join(', '), 400);
  const exists = await Vehicle.findByRegNumber(req.body.registration_number);
  if (exists) throw new AppError('Registration number already exists', 400);
  const id = await Vehicle.create(req.body);
  successResponse(res, { id }, 'Vehicle created', 201);
});

exports.update = catchAsync(async (req, res) => {
  const vehicle = await Vehicle.findById(req.params.id);
  if (!vehicle) throw new AppError('Vehicle not found', 404);
  // prevent changing reg number to existing one
  if (req.body.registration_number && req.body.registration_number !== vehicle.registration_number) {
    const dup = await Vehicle.findByRegNumber(req.body.registration_number);
    if (dup) throw new AppError('Registration number already in use', 400);
  }
  await Vehicle.update(req.params.id, req.body);
  successResponse(res, null, 'Vehicle updated');
});

exports.delete = catchAsync(async (req, res) => {
  const vehicle = await Vehicle.findById(req.params.id);
  if (!vehicle) throw new AppError('Vehicle not found', 404);
  // maybe check if vehicle is assigned to active trips
  await Vehicle.delete(req.params.id);
  successResponse(res, null, 'Vehicle deleted');
});