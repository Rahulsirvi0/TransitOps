const Trip = require('../models/Trip');
const Vehicle = require('../models/Vehicle');
const Driver = require('../models/Driver');
const AuditLog = require('../models/AuditLog');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const { successResponse } = require('../utils/response');

exports.list = catchAsync(async (req, res) => {
  const { page, limit, search, status, vehicle_id, driver_id, startDate, endDate, sortBy, order } = req.query;
  const result = await Trip.findAll({ page: parseInt(page) || 1, limit: parseInt(limit) || 10, search, status, vehicle_id, driver_id, startDate, endDate, sortBy, order });
  successResponse(res, result);
});

exports.getById = catchAsync(async (req, res) => {
  const trip = await Trip.findById(req.params.id);
  if (!trip) throw new AppError('Trip not found', 404);
  successResponse(res, trip);
});

exports.create = catchAsync(async (req, res) => {
  const { trip_number, vehicle_id, driver_id, cargo_weight } = req.body;
  const exists = await Trip.findByTripNumber(trip_number);
  if (exists) throw new AppError('Trip number already exists', 400);
  // Validate vehicle and driver availability and constraints
  const vehicle = await Vehicle.findById(vehicle_id);
  if (!vehicle) throw new AppError('Vehicle not found', 404);
  if (vehicle.status === 'Retired' || vehicle.status === 'In Shop') throw new AppError('Vehicle not available (retired/in shop)', 400);
  if (vehicle.status === 'On Trip') throw new AppError('Vehicle already on a trip', 400);
  if (cargo_weight > vehicle.max_load_capacity) throw new AppError('Cargo weight exceeds vehicle capacity', 400);
  const driver = await Driver.findById(driver_id);
  if (!driver) throw new AppError('Driver not found', 404);
  if (driver.status === 'Suspended') throw new AppError('Driver is suspended', 400);
  if (driver.status === 'On Trip') throw new AppError('Driver already on a trip', 400);
  if (new Date(driver.license_expiry) < new Date()) throw new AppError('Driver license expired', 400);
  const id = await Trip.create(req.body);
  await AuditLog.log(req.user.id, 'CREATE', 'Trip', id, req.body);
  successResponse(res, { id }, 'Trip created', 201);
});

exports.update = catchAsync(async (req, res) => {
  const trip = await Trip.findById(req.params.id);
  if (!trip) throw new AppError('Trip not found', 404);
  if (trip.status !== 'Draft') throw new AppError('Only draft trips can be edited', 400);
  await Trip.update(req.params.id, req.body);
  await AuditLog.log(req.user.id, 'UPDATE', 'Trip', req.params.id, req.body);
  successResponse(res, null, 'Trip updated');
});

exports.delete = catchAsync(async (req, res) => {
  const trip = await Trip.findById(req.params.id);
  if (!trip) throw new AppError('Trip not found', 404);
  if (trip.status !== 'Draft') throw new AppError('Only draft trips can be deleted', 400);
  await Trip.delete(req.params.id);
  await AuditLog.log(req.user.id, 'DELETE', 'Trip', req.params.id);
  successResponse(res, null, 'Trip deleted');
});

exports.dispatch = catchAsync(async (req, res) => {
  const trip = await Trip.findById(req.params.id);
  if (!trip) throw new AppError('Trip not found', 404);
  if (trip.status !== 'Draft') throw new AppError('Trip not in Draft status', 400);
  // Re-validate constraints (may have changed)
  const vehicle = await Vehicle.findById(trip.vehicle_id);
  const driver = await Driver.findById(trip.driver_id);
  if (vehicle.status !== 'Available' || vehicle.status === 'Retired') throw new AppError('Vehicle not available', 400);
  if (driver.status !== 'Available') throw new AppError('Driver not available', 400);
  if (new Date(driver.license_expiry) < new Date()) throw new AppError('Driver license expired', 400);
  if (trip.cargo_weight > vehicle.max_load_capacity) throw new AppError('Cargo weight exceeds vehicle capacity', 400);
  // Update statuses
  await Trip.updateStatus(trip.id, 'Dispatched');
  await Vehicle.updateStatus(vehicle.id, 'On Trip');
  await Driver.updateStatus(driver.id, 'On Trip');
  await AuditLog.log(req.user.id, 'DISPATCH', 'Trip', trip.id);
  successResponse(res, null, 'Trip dispatched');
});

exports.complete = catchAsync(async (req, res) => {
  const trip = await Trip.findById(req.params.id);
  if (!trip) throw new AppError('Trip not found', 404);
  if (trip.status !== 'Dispatched') throw new AppError('Only dispatched trips can be completed', 400);
  const { actual_distance, revenue } = req.body;
  if (!actual_distance || !revenue) throw new AppError('Actual distance and revenue required', 400);
  await Trip.complete(trip.id, actual_distance, revenue);
  await Vehicle.updateStatus(trip.vehicle_id, 'Available');
  await Driver.updateStatus(trip.driver_id, 'Available');
  await AuditLog.log(req.user.id, 'COMPLETE', 'Trip', trip.id, { actual_distance, revenue });
  successResponse(res, null, 'Trip completed');
});

exports.cancel = catchAsync(async (req, res) => {
  const trip = await Trip.findById(req.params.id);
  if (!trip) throw new AppError('Trip not found', 404);
  if (trip.status === 'Completed') throw new AppError('Cannot cancel completed trip', 400);
  // If it was already dispatched, restore vehicle and driver
  if (trip.status === 'Dispatched') {
    await Vehicle.updateStatus(trip.vehicle_id, 'Available');
    await Driver.updateStatus(trip.driver_id, 'Available');
  }
  await Trip.updateStatus(trip.id, 'Cancelled');
  await AuditLog.log(req.user.id, 'CANCEL', 'Trip', trip.id);
  successResponse(res, null, 'Trip cancelled');
});