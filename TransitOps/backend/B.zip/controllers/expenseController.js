const Expense = require('../models/Expense');
const AuditLog = require('../models/AuditLog');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const { successResponse } = require('../utils/response');

exports.list = catchAsync(async (req, res) => {
  const { page, limit, vehicle_id, expense_type, startDate, endDate, sortBy, order } = req.query;
  const result = await Expense.findAll({ page: parseInt(page) || 1, limit: parseInt(limit) || 10, vehicle_id, expense_type, startDate, endDate, sortBy, order });
  successResponse(res, result);
});

exports.getById = catchAsync(async (req, res) => {
  const expense = await Expense.findById(req.params.id);
  if (!expense) throw new AppError('Expense not found', 404);
  successResponse(res, expense);
});

exports.create = catchAsync(async (req, res) => {
  const id = await Expense.create(req.body);
  await AuditLog.log(req.user.id, 'CREATE', 'Expense', id, req.body);
  successResponse(res, { id }, 'Expense created', 201);
});

exports.update = catchAsync(async (req, res) => {
  const expense = await Expense.findById(req.params.id);
  if (!expense) throw new AppError('Expense not found', 404);
  await Expense.update(req.params.id, req.body);
  await AuditLog.log(req.user.id, 'UPDATE', 'Expense', req.params.id, req.body);
  successResponse(res, null, 'Expense updated');
});

exports.delete = catchAsync(async (req, res) => {
  const expense = await Expense.findById(req.params.id);
  if (!expense) throw new AppError('Expense not found', 404);
  await Expense.delete(req.params.id);
  await AuditLog.log(req.user.id, 'DELETE', 'Expense', req.params.id);
  successResponse(res, null, 'Expense deleted');
});