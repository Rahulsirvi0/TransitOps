
const catchAsync = require('../utils/catchAsync');

exports.tripSummary = catchAsync(async (req, res) => {
  const { startDate, endDate, vehicle_id, driver_id, region_id, status, format } = req.query;
  let query = `SELECT t.*, v.name as vehicle_name, d.name as driver_name FROM trips t JOIN vehicles v ON t.vehicle_id=v.id JOIN drivers d ON t.driver_id=d.id WHERE 1=1`;
  const params = [];
  if (startDate) { query += ` AND t.created_at >= ?`; params.push(startDate); }
  if (endDate) { query += ` AND t.created_at <= ?`; params.push(endDate); }
  if (vehicle_id) { query += ` AND t.vehicle_id = ?`; params.push(vehicle_id); }
  if (driver_id) { query += ` AND t.driver_id = ?`; params.push(driver_id); }
  if (status) { query += ` AND t.status = ?`; params.push(status); }
  const [rows] = await pool.query(query, params);
  if (format === 'csv') {
    const { Parser } = require('json2csv');
    const parser = new Parser();
    const csv = parser.parse(rows);
    res.header('Content-Type', 'text/csv');
    res.attachment('trip_summary.csv');
    return res.send(csv);
  } else if (format === 'pdf') {
    const PDFDocument = require('pdfkit');
    const doc = new PDFDocument();
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename=trip_summary.pdf');
    doc.pipe(res);
    doc.fontSize(16).text('Trip Summary Report', { align: 'center' });
    doc.moveDown();
    // table header
    const tableTop = 150;
    // simplistic table
    rows.forEach((row, i) => {
      doc.fontSize(10).text(`${row.trip_number} | ${row.source} -> ${row.destination} | ${row.status} | Revenue: ${row.revenue}`, 50, tableTop + i*20);
    });
    doc.end();
  } else {
    successResponse(res, rows);
  }
});