
const catchAsync = require('../utils/catchAsync');

exports.getKPIs = catchAsync(async (req, res) => {
  const [[{ activeTrips }]] = await pool.query(`SELECT COUNT(*) as activeTrips FROM trips WHERE status='Dispatched'`);
  const [[{ availableVehicles }]] = await pool.query(`SELECT COUNT(*) as availableVehicles FROM vehicles WHERE status='Available'`);
  const [[{ inMaintenance }]] = await pool.query(`SELECT COUNT(*) as inMaintenance FROM vehicles WHERE status='In Shop'`);
  const [[{ driversOnDuty }]] = await pool.query(`SELECT COUNT(*) as driversOnDuty FROM drivers WHERE status='On Trip'`);
  const [[{ fleetUtilization }]] = await pool.query(`SELECT ROUND((SELECT COUNT(*) FROM vehicles WHERE status='On Trip') / COUNT(*) * 100, 1) as fleetUtilization FROM vehicles`);
  // Recent trips, expenses, maintenance
  const [recentTrips] = await pool.query(`SELECT t.*, v.name as vehicle_name, d.name as driver_name FROM trips t JOIN vehicles v ON t.vehicle_id=v.id JOIN drivers d ON t.driver_id=d.id ORDER BY t.created_at DESC LIMIT 5`);
  const [recentExpenses] = await pool.query(`SELECT e.*, v.name as vehicle_name FROM expenses e LEFT JOIN vehicles v ON e.vehicle_id=v.id ORDER BY e.created_at DESC LIMIT 5`);
  const [recentMaintenance] = await pool.query(`SELECT m.*, v.name as vehicle_name FROM maintenance m JOIN vehicles v ON m.vehicle_id=v.id ORDER BY m.created_at DESC LIMIT 5`);
  successResponse(res, {
    activeTrips,
    availableVehicles,
    inMaintenance,
    driversOnDuty,
    fleetUtilization,
    recentTrips,
    recentExpenses,
    recentMaintenance
  });
});

// Charts data: trips per month, vehicle status distribution, fuel cost, maintenance cost
exports.getCharts = catchAsync(async (req, res) => {
  const { year } = req.query;
  const yearFilter = year || new Date().getFullYear();
  const [tripsPerMonth] = await pool.query(`SELECT MONTH(created_at) as month, COUNT(*) as count FROM trips WHERE YEAR(created_at)=? AND status='Completed' GROUP BY MONTH(created_at)`, [yearFilter]);
  const [vehicleStatus] = await pool.query(`SELECT status, COUNT(*) as count FROM vehicles GROUP BY status`);
  const [fuelCost] = await pool.query(`SELECT MONTH(log_date) as month, SUM(fuel_cost) as total FROM fuel_logs WHERE YEAR(log_date)=? GROUP BY MONTH(log_date)`, [yearFilter]);
  const [maintenanceCost] = await pool.query(`SELECT MONTH(maintenance_date) as month, SUM(cost) as total FROM maintenance WHERE YEAR(maintenance_date)=? GROUP BY MONTH(maintenance_date)`, [yearFilter]);
  successResponse(res, { tripsPerMonth, vehicleStatus, fuelCost, maintenanceCost });
});