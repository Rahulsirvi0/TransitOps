const Maintenance = require('../models/Maintenance');
const Vehicle = require('../models/Vehicle');
const AuditLog = require('../models/AuditLog');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const { successResponse } = require('../utils/response');

exports.list = catchAsync(async (req, res) => {
  const { page, limit, vehicle_id, status, startDate, endDate, sortBy, order } = req.query;
  const result = await Maintenance.findAll({ page: parseInt(page) || 1, limit: parseInt(limit) || 10, vehicle_id, status, startDate, endDate, sortBy, order });
  successResponse(res, result);
});

exports.getById = catchAsync(async (req, res) => {
  const m = await Maintenance.findById(req.params.id);
  if (!m) throw new AppError('Maintenance record not found', 404);
  successResponse(res, m);
});

exports.create = catchAsync(async (req, res) => {
  const vehicle = await Vehicle.findById(req.body.vehicle_id);
  if (!vehicle) throw new AppError('Vehicle not found', 404);
  // When creating maintenance, set vehicle to In Shop (unless already)
  await Vehicle.updateStatus(vehicle.id, 'In Shop');
  const id = await Maintenance.create(req.body);
  await AuditLog.log(req.user.id, 'CREATE', 'Maintenance', id, req.body);
  successResponse(res, { id }, 'Maintenance record created, vehicle set to In Shop', 201);
});

exports.update = catchAsync(async (req, res) => {
  const m = await Maintenance.findById(req.params.id);
  if (!m) throw new AppError('Maintenance record not found', 404);
  await Maintenance.update(req.params.id, req.body);
  await AuditLog.log(req.user.id, 'UPDATE', 'Maintenance', req.params.id, req.body);
  successResponse(res, null, 'Maintenance updated');
});

exports.updateStatus = catchAsync(async (req, res) => {
  const { status } = req.body;
  if (!['Open', 'In Progress', 'Completed'].includes(status)) throw new AppError('Invalid status', 400);
  const m = await Maintenance.findById(req.params.id);
  if (!m) throw new AppError('Maintenance record not found', 404);
  const oldStatus = m.status;
  await Maintenance.updateStatus(m.id, status);
  // If completed, restore vehicle if not retired
  if (status === 'Completed' && oldStatus !== 'Completed') {
    const vehicle = await Vehicle.findById(m.vehicle_id);
    if (vehicle && vehicle.status !== 'Retired') {
      await Vehicle.updateStatus(vehicle.id, 'Available');
    }
  }
  await AuditLog.log(req.user.id, 'STATUS_CHANGE', 'Maintenance', m.id, { from: oldStatus, to: status });
  successResponse(res, null, `Maintenance status updated to ${status}`);
});

exports.delete = catchAsync(async (req, res) => {
  const m = await Maintenance.findById(req.params.id);
  if (!m) throw new AppError('Maintenance record not found', 404);
  // If maintenance was ongoing, maybe restore vehicle? Best to prevent deletion of active ones.
  await Maintenance.delete(req.params.id);
  await AuditLog.log(req.user.id, 'DELETE', 'Maintenance', req.params.id);
  successResponse(res, null, 'Maintenance record deleted');
});