const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const User = require('../models/User');
const pool = require('../config/db');
const { jwtSecret, jwtRefreshSecret, jwtExpire, jwtRefreshExpire } = require('../config/auth');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const { successResponse, errorResponse } = require('../utils/response');

const generateTokens = (user) => {
  const accessToken = jwt.sign({ id: user.id, email: user.email, role: user.role }, jwtSecret, { expiresIn: jwtExpire });
  const refreshToken = jwt.sign({ id: user.id }, jwtRefreshSecret, { expiresIn: jwtRefreshExpire });
  return { accessToken, refreshToken };
};

const ensureRefreshTokenTable = async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS refresh_tokens (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT UNSIGNED NOT NULL,
      token VARCHAR(512) NOT NULL UNIQUE,
      expires_at DATETIME NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX (user_id),
      INDEX (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);
};

exports.login = catchAsync(async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) throw new AppError('Email and password required', 400);
  const user = await User.findByEmail(email);
  if (!user || user.status !== 'active') throw new AppError('Invalid credentials', 401);
  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) throw new AppError('Invalid credentials', 401);
  const tokens = generateTokens(user);
  await ensureRefreshTokenTable();
  await pool.query(`INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))`, [user.id, tokens.refreshToken]);
  successResponse(res, { user: { id: user.id, email: user.email, full_name: user.full_name, role: user.role }, ...tokens }, 'Login successful');
});

exports.refreshToken = catchAsync(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) throw new AppError('Refresh token required', 400);
  await ensureRefreshTokenTable();
  const [rows] = await pool.query(`SELECT * FROM refresh_tokens WHERE token = ? AND expires_at > NOW()`, [refreshToken]);
  if (!rows.length) throw new AppError('Invalid or expired refresh token', 401);
  const tokenData = rows[0];
  let decoded;
  try { decoded = jwt.verify(refreshToken, jwtRefreshSecret); } catch { throw new AppError('Invalid token', 401); }
  const [userRows] = await pool.query(`SELECT u.*, r.name as role FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?`, [decoded.id]);
  if (!userRows.length) throw new AppError('User not found', 401);
  const user = userRows[0];
  const tokens = generateTokens(user);
  await pool.query(`DELETE FROM refresh_tokens WHERE id = ?`, [tokenData.id]);
  await pool.query(`INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))`, [user.id, tokens.refreshToken]);
  successResponse(res, tokens);
});

exports.me = catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT u.id, u.email, u.full_name, r.name as role
     FROM users u
     JOIN roles r ON u.role_id = r.id
     WHERE u.id = ?`,
    [req.user.id]
  );
  if (!rows.length) throw new AppError('User not found', 404);
  successResponse(res, rows[0]);
});

exports.logout = catchAsync(async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) await pool.query(`DELETE FROM refresh_tokens WHERE token = ?`, [refreshToken]);
  successResponse(res, null, 'Logged out');
});

exports.forgotPassword = catchAsync(async (req, res) => {
  // In production, send reset email. Here we just confirm email exists.
  const { email } = req.body;
  const user = await User.findByEmail(email);
  if (!user) throw new AppError('If email exists, reset link sent.', 200); // avoid user enumeration
  // simulate
  successResponse(res, null, 'If email exists, reset link sent.');
});