const FuelLog = require('../models/FuelLog');
const AuditLog = require('../models/AuditLog');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const { successResponse } = require('../utils/response');

exports.list = catchAsync(async (req, res) => {
  const { page, limit, vehicle_id, trip_id, startDate, endDate, sortBy, order } = req.query;
  const result = await FuelLog.findAll({ page: parseInt(page) || 1, limit: parseInt(limit) || 10, vehicle_id, trip_id, startDate, endDate, sortBy, order });
  successResponse(res, result);
});

exports.getById = catchAsync(async (req, res) => {
  const log = await FuelLog.findById(req.params.id);
  if (!log) throw new AppError('Fuel log not found', 404);
  successResponse(res, log);
});

exports.create = catchAsync(async (req, res) => {
  const id = await FuelLog.create(req.body);
  await AuditLog.log(req.user.id, 'CREATE', 'FuelLog', id, req.body);
  successResponse(res, { id }, 'Fuel log created', 201);
});

exports.update = catchAsync(async (req, res) => {
  const log = await FuelLog.findById(req.params.id);
  if (!log) throw new AppError('Fuel log not found', 404);
  await FuelLog.update(req.params.id, req.body);
  await AuditLog.log(req.user.id, 'UPDATE', 'FuelLog', req.params.id, req.body);
  successResponse(res, null, 'Fuel log updated');
});

exports.delete = catchAsync(async (req, res) => {
  const log = await FuelLog.findById(req.params.id);
  if (!log) throw new AppError('Fuel log not found', 404);
  await FuelLog.delete(req.params.id);
  await AuditLog.log(req.user.id, 'DELETE', 'FuelLog', req.params.id);
  successResponse(res, null, 'Fuel log deleted');
});