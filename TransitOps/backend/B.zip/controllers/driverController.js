const Driver = require('../models/Driver');
const AuditLog = require('../models/AuditLog');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const { successResponse } = require('../utils/response');

exports.list = catchAsync(async (req, res) => {
  const { page, limit, search, status, licenseCategory, sortBy, order } = req.query;
  const result = await Driver.findAll({ page: parseInt(page) || 1, limit: parseInt(limit) || 10, search, status, licenseCategory, sortBy, order });
  successResponse(res, result);
});

exports.getById = catchAsync(async (req, res) => {
  const driver = await Driver.findById(req.params.id);
  if (!driver) throw new AppError('Driver not found', 404);
  successResponse(res, driver);
});

exports.create = catchAsync(async (req, res) => {
  const exists = await Driver.findByLicense(req.body.license_number);
  if (exists) throw new AppError('License number already exists', 400);
  const id = await Driver.create(req.body);
  await AuditLog.log(req.user.id, 'CREATE', 'Driver', id, req.body);
  successResponse(res, { id }, 'Driver created', 201);
});

exports.update = catchAsync(async (req, res) => {
  const driver = await Driver.findById(req.params.id);
  if (!driver) throw new AppError('Driver not found', 404);
  if (req.body.license_number && req.body.license_number !== driver.license_number) {
    const dup = await Driver.findByLicense(req.body.license_number);
    if (dup) throw new AppError('License number already in use', 400);
  }
  await Driver.update(req.params.id, req.body);
  await AuditLog.log(req.user.id, 'UPDATE', 'Driver', req.params.id, req.body);
  successResponse(res, null, 'Driver updated');
});

exports.delete = catchAsync(async (req, res) => {
  const driver = await Driver.findById(req.params.id);
  if (!driver) throw new AppError('Driver not found', 404);
  await Driver.delete(req.params.id);
  await AuditLog.log(req.user.id, 'DELETE', 'Driver', req.params.id);
  successResponse(res, null, 'Driver deleted');
});